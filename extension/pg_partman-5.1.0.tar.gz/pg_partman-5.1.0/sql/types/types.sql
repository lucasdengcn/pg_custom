CREATE TYPE @extschema@.check_default_table AS (default_table text, count bigint);
