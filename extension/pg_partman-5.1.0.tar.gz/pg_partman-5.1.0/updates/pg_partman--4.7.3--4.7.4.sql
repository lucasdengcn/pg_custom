-- NOTE: No changes to the sql extension code contained in this update. This file is only here for version upgrade continuity.

-- Add support for PostgreSQL 16 (Github PR #508)
-- Update doc formatting (Github PR #547)
