CREATE TABLE memos (
  id integer,
  user_name text,
  content text
);

CREATE USER alice NOLOGIN;
GRANT ALL ON TABLE memos TO alice;

INSERT INTO memos VALUES
  (1, 'nonexistent', 'PostgreSQL is a RDBMS.');
INSERT INTO memos VALUES
  (2, 'alice', 'Groonga is fast full text search engine.');
INSERT INTO memos VALUES
  (3, 'alice', 'PGroonga is a PostgreSQL extension that uses Groonga.');

ALTER TABLE memos ENABLE ROW LEVEL SECURITY;
CREATE POLICY memos_myself ON memos USING (user_name = current_user);

SET enable_seqscan = on;
SET enable_indexscan = off;
SET enable_bitmapscan = off;

SET SESSION AUTHORIZATION alice;
\pset format unaligned
EXPLAIN (COSTS OFF)
SELECT id, content
  FROM memos
 WHERE content &` 'content @ "rdbms" || content @ "engine"'
\g |sed -r -e "s/\(CURRENT_USER\)::text/CURRENT_USER/g"
\pset format aligned

SELECT id, content
  FROM memos
 WHERE content &` 'content @ "rdbms" || content @ "engine"';

\pset format unaligned
EXPLAIN (COSTS OFF)
SELECT id, content
  FROM memos
 WHERE content &` 'content @ "rdbms" ||'
\g |sed -r -e "s/\(CURRENT_USER\)::text/CURRENT_USER/g"
\pset format aligned

\pset format unaligned
EXPLAIN (ANALYZE ON, COSTS OFF)
SELECT id, content
  FROM memos
 WHERE content &` 'content @ "rdbms" ||'
\g |sed -r -e "s/\(CURRENT_USER\)::text/CURRENT_USER/g" -e "s/actual time=[^ ]*/actual time=0..0/g" -e "s/[Tt]ime: [^ ]* ms/Time: 0.0 ms/g"
\pset format aligned

SELECT id, content
  FROM memos
 WHERE content &` 'content @ "rdbms" ||';
RESET SESSION AUTHORIZATION;

DROP TABLE memos;

DROP USER alice;
