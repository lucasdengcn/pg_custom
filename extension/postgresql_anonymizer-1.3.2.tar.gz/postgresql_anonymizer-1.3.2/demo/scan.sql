

BEGIN;

CREATE TABLE suggest(
	attname TEXT,
	suggested_mask TEXT	
);

INSERT INTO suggest 
VALUES 
('firstname','random_first_name()'),
('first_name','random_first_name()'),
('given_name','random_first_name()'),
('prenom','random_first_name()'),
('creditcard','FIXME'),
('credit_card','FIXME'),
('CB','FIXME'),
('carte_bancaire','FIXME'),
('cartebancaire','FIXME')
;

SELECT 
  a.attrelid,
  a.attname,
  s.suggested_mask,
  pg_catalog.col_description(a.attrelid, a.attnum)
FROM pg_catalog.pg_attribute a
JOIN suggest s ON  lower(a.attname) = s.attname
;

ROLLBACK;
